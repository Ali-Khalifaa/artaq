<template>
    <!-- Footer Start -->
    <footer class="footer mt-auto py-3 bg-white text-center">
        <div class="container">
                <span class="text-muted"> Copyright © <span>{{ new Date().getFullYear()}}</span>
<!--                    <a-->
<!--                    href="javascript:void(0);" class="text-dark fw-semibold">Ynex</a>.-->
<!--                    Designed with <span class="bi bi-heart-fill text-danger"></span> by <a href="javascript:void(0);">-->
<!--                        <span class="fw-semibold text-primary text-decoration-underline">Spruko</span>-->
<!--                    </a> All-->
<!--                    rights-->
<!--                    reserved-->
                </span>
        </div>
    </footer>
    <!-- Footer End -->
</template>

<script>
export default {
    name: "Footer",
}
</script>

<style scoped>

</style>
